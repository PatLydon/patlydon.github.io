$(function(){
  $('.burger, .menu a').on('click', function () {
    $('.menu').toggleClass('menu--active');
  });

});
